# MSFG Mortgage Site

Static website for `msfgmortgage.com`, designed for AWS Amplify Hosting with Git-based deploys.

## Pages

- `/` - simple MSFG Mortgage webinar landing page
- `/webinars/` - webinar library
- `/webinars/homebuyers-webinar/` - first-time homebuyer presentation

## AWS Amplify

Use this folder as the repository root.

In Amplify:

1. Choose `Host web app`.
2. Connect the Git provider/repository.
3. Use the included `amplify.yml` build settings.
4. Deploy the main branch.
5. Test the temporary `amplifyapp.com` URL before editing Porkbun DNS.

## Domain

After the Amplify preview works, add the custom domain in Amplify:

- `msfgmortgage.com`
- `www.msfgmortgage.com`

Then update Porkbun only with the records Amplify gives you. Keep existing email, MX, SPF, DKIM, DMARC, and Google verification records unless AWS explicitly tells you otherwise.

## Local Preview

Open `index.html` locally for the homepage, or open:

`webinars/homebuyers-webinar/index.html`

for the presentation.
