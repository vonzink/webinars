# MSFG Mortgage Amplify Site

Upload this folder as a zip to AWS Amplify Hosting.

## URLs

- Homepage: `/`
- Homebuyer webinar: `/webinars/homebuyers-webinar/`

## Upload File

Use:

`/Users/zacharyzink/MSFG/Webinars/Homebuyers-Webinar/Export/msfgmortgage-site-amplify-v1.0.zip`

## Amplify Settings

Choose manual deploy / deploy without Git provider, then upload the zip.

Test the temporary Amplify URL before changing Porkbun DNS.
